#include <bits/stdc++.h>
using namespace std;
#define V 7 

int minKey(int val[], bool mstinclude[]) 
{ 
    int min = INT_MAX, minIndex; 

    for (int v = 0; v < V; v++) 
        if (mstinclude[v] == false && val[v] < min) 
            min = val[v], minIndex = v; 

    return minIndex; 
} 

void ShowMST(int parent[], int graph[V][V]) 
{ 
    cout<<"Edge \tWeight\n"; 
    for (int i = 1; i < V; i++) 
        cout<<parent[i]<<" - "<<i<<" \t"<<graph[i][parent[i]]<<" \n"; 
} 

void PrimMST(int graph[V][V]) 
{ 
    int parent[V]; 
        int val[V]; 
    bool mstinclude[V]; 
    
    for (int i = 0; i < V; i++) 
        val[i] = INT_MAX, mstinclude[i] = false; 
        
    val[0] = 0; 
    parent[0] = -1; 

    for (int count = 0; count < V - 1; count++)
    { 
        int u = minKey(val, mstinclude); 

        mstinclude[u] = true; 
        for (int v = 0; v < V; v++) 
 
            if (graph[u][v] && mstinclude[v] == false && graph[u][v] < val[v]) 
                parent[v] = u, val[v] = graph[u][v]; 
    } 
    ShowMST(parent, graph); 
} 

int main() 
{ 
    
    int graph[V][V] = { { 0, 2, 4, 1, 0, 0 ,0 }, 
                        { 2, 0, 0, 3, 10, 0, 0 }, 
                        { 4, 0, 0,2 ,0 ,5 ,0 }, 
                        { 1, 3, 2,0 ,7 ,8 ,4 }, 
                        { 0, 10, 0,7 ,0 ,0 ,6 } ,
                        { 0, 0,5 ,8 ,0 ,0 ,1},
                        { 0, 0, 0, 4 ,6 ,1 ,0} }; 

    PrimMST(graph); 

    return 0; 
}
