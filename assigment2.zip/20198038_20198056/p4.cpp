#include <iostream>
#include <bits/stdc++.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
struct Activitiy
{
    int start,end;
};
bool Compareactivity(Activitiy a, Activitiy b)
{
    return (a.end<b.end);
}
void printmaxAct(Activitiy arr[], int size)
{
    sort(arr, arr+size, Compareactivity);
    int i = 0;
    cout << "{" << arr[i].start << ", " << arr[i].end<< "}, ";
    for (int j=1;j<size; j++)
    {
      if (arr[j].start>=arr[i].end)
      {
          cout <<"{" <<arr[j].start<< ", "<<arr[j].end<< "}, ";
          i=j;
      }
    }
}
int main()
{
   
    Activitiy arr[]={{1, 4},{3, 5},{0, 6},{5,7},{3, 8},{5, 9},{6,10},{8,11},{8,12},{2,13},{12,14}};
    int size= sizeof(arr)/sizeof(arr[0]);
    printmaxAct(arr,size);
    return 0;
}
