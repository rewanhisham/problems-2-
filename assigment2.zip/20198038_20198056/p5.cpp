#include <iostream>
#include <vector>
#include <cmath>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int Catchthief(char arr[], int size, int val)
{
    int ans = 0;
    vector<int> T;
    vector<int> P;
    for (int i = 0; i<size; i++) 
    {
        if (arr[i]=='P')
        {
            P.push_back(i);
        }
        else if (arr[i]=='T')
        {
            T.push_back(i);
        }
    }   
    int l = 0, r = 0;
    while (P.size()>r && T.size()>l )
    {
        if (abs(T[l]-P[r])<=val)
        {
            ans++;
            l++;
            r++;
        }
        else if (P[r]>T[l])
        {
            l++;
        }
        else
        {
            r++;
        }
    }

    return ans;
}
int main()
{
    int k, n;
    cin>>n>>k;
    char arr[n]; 
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<Catchthief(arr,n,k)<<"\n";
    return 0;
}

int main(int argc, char** argv) {
	return 0;
}
