#include <bits/stdc++.h>
 
using namespace std;
 
 
const int N = 100005;
 
int a[N], cnt[N], fre[N], fr[N];
long long res[N];
vector<int> v;
 
 
struct query {
    int l, r, id, k;
};
query q[N];
 
bool cmp(query a, query b) {
    return a.k < b.k || (a.k == b.k && a.r < b.r);
}
 
void update(int pos, int val) {
    fre[cnt[pos]]--;
    cnt[pos] += val;
    fre[cnt[pos]]++;
}
 
 
int main() {
    int n;
    cin >> n;
    int size = sqrt(n) + 1;
 
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        cnt[a[i]]++;
        if (cnt[a[i]] == size) v.push_back(a[i]);
    }
    int m;
    cin >> m;
    for (int i = 1; i <= m; i++) {
        cin >> q[i].l >> q[i].r;
        q[i].id = i;
        q[i].k = q[i].l / size;
    }
 
    sort(q + 1, q + m + 1, cmp);
    int left = 1;
    int right = 0;
 
    memset(cnt, 0, sizeof(cnt));
 
    fre[0] = n;
    for (int i = 1; i <= m; i++) {
        while (left < q[i].l) {
            update(a[left], -1), left++;
        }
        while (left > q[i].l) {
            left--;
            update(a[left], 1);
        }
        while (right > q[i].r) {
            update(a[right], -1), right--;
        }
        while (right < q[i].r) {
            right++;
            update(a[right], 1);
        }
 
        priority_queue<int, vector<int>, greater<int> > tree;
 
        memcpy(fr, fre, sizeof(int) * (size + 5));
 
        res[q[i].id] = 0;
        for (int j = 0; j < v.size(); j++)
            if (cnt[v[j]] >= size)
                tree.push(cnt[v[j]]);
 
        long long last = 0;
        for (int j = 1; j < size; j++) {
            if (fr[j] > 0) {
                if (last) {
                    fr[j]--;
                    res[q[i].id] += last + j;
 
                    if (last + j < size)
                        fr[last + j]++;
                    else
                        tree.push(last + j);
 
                    last = 0;
                }
                if (fr[j] % 2 == 1)
                    fr[j]--, last = j;
 
                res[q[i].id] += fr[j] * j;
 
                if (2 * j >= size)
                    for (int k = 1; k <= fr[j] / 2; k++)
                        tree.push(j * 2);
                else
                    fr[j * 2] += fr[j] / 2;
            }
        }
        if (last) tree.push(last);
        while (tree.size() > 1) {
            long long b = tree.top();
            tree.pop();
            int c = tree.top();
            tree.pop();
            res[q[i].id] += b + c;
            tree.push(b + c);
        }
    }
 
    for (int i = 1; i <= m; i++)
        cout << res[i] << '\n';
 
    return 0;
}