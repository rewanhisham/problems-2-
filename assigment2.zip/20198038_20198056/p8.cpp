#include <iostream>
#include<algorithm>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
struct Job
{
    char Jobid;
    int deadline;
    int profit;
};
bool compar(Job a1, Job a2)
{
	return (a1.profit>a2.profit);
}
void printJobScheduling(Job arr[], int size)
{
	sort(arr, arr+size, compar);
	int result[size]; 
	bool part[size]; 
	for (int i=0; i<size; i++)
	{
		part[i] = false;
	}
	for (int i=0;i<size;i++)
	{
	     for (int j=min(size, arr[i].deadline)-1; j>=0; j--)
	     {
		
	    	if (part[j]==false)
		    {
		    	result[j] = i; 
		    	part[j] = true; 
			    break;
		    }
		}
	}
	for (int i=0; i<size; i++)
	{
	    if (part[i]!=0)
	    {
	    	cout << arr[result[i]].Jobid << " ";
	    }
	}
}
int main()
{
    /*int row,col;
    cin>>row>>col;
    Job *arr=new Job[row*col];
    for (int i = 0; i < row; ++i)
    {
        for (int j = 0; j < col; ++j)
        {
            cin >> arr[i][j]->jobid>>arr[i][j]->deadline>>arr[i][j]->profit;
        }
    }*/
	Job arr1[] = { {'a',4, 20}, {'b', 1, 10}, {'c',1,40},{'d', 1, 30}};
	int n = sizeof(arr1)/sizeof(arr1[0]);
	cout<<"Following is maximum profit sequence of jobs(1): ";
	printJobScheduling(arr1, n);
	Job arr2[] = { {'a', 2, 100}, {'b', 1, 19}, {'c', 2, 27},{'d', 1, 25}, {'e', 3, 15}};
	int n2 = sizeof(arr2)/sizeof(arr2[0]);
	cout << "\nFollowing is maximum profit sequence of jobs(2): ";
	printJobScheduling(arr2, n2);
	return 0;
}
